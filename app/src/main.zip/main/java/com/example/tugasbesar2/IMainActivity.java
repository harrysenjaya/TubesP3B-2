package com.example.tugasbesar2;

public interface IMainActivity {
}
